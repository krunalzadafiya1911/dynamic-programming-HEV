%% Script description
% -------------------------------------------------------------------------
% This script runs NEDC and FTP-75 simulations of QSS toolbox. Other
% information about QSS toolbox can be found on ...
% https://idsc.ethz.ch/research-guzzella-onder/downloads.html

%% Model setup
filepath = 'qss_hybrid_electric_vehicle_example.mdl';
% Load simulink model
load_system(filepath);
% set FTP-75 cycle
set_param(strcat(filepath(1:end-4),'/Driving Cycle'),'cyclenr', 17); % DO NOT CHANGE


%% Paramater setup for FTP-75

% ------------------------------NOTE---------------------------------------%
% value step can be changed with exterme care. Because it will change
% simulation time accordingly. If you set 0.01 value step, simulation can
% take 1 year to complete so be careful.
% ------------------------------NOTE ENDS----------------------------------%

T_MGB_th_lower_FTP = 50;
T_MGB_th_upper_FTP = 100;
T_MGB_TH_FTP = T_MGB_th_lower_FTP:1:T_MGB_th_upper_FTP; % step = 1...51

T_lower_FTP = 20;
T_upper_FTP = 40;
T_TH_FTP = T_lower_FTP:1:T_upper_FTP; % step = 1....6

u_LPS_min_lower_FTP = -0.2;
u_LPS_min_upper_FTP = -0.7;
U_LPS_MIN_FTP = u_LPS_min_lower_FTP:-0.002:u_LPS_min_upper_FTP; % step = 0.1...250


soc_min_FTP = 0.15;
soc_max_FTP = 0.35;
SOC_FTP = soc_min_FTP:0.2:soc_max_FTP; %step = 0.05....2

[X_FTP,Y_FTP,Z_FTP,SS_FTP] = ndgrid(T_MGB_TH_FTP, T_TH_FTP, U_LPS_MIN_FTP, SOC_FTP);

%% Paramater setup for NEDC cycle

%------------------------------NOTE---------------------------------------%
% value step can be changed with exterme care. Because it will change
% simulation time accordingly. If you set 0.01 value step, simulation can
% take 1 year to complete so be careful.
%------------------------------NOTE ENDS----------------------------------%
% 
% T_MGB_th_lower_NEDC = 50;
% T_MGB_th_upper_NEDC = 90;
% T_MGB_TH_NEDC = T_MGB_th_lower_NEDC:1:T_MGB_th_upper_NEDC;
% 
% T_lower_NEDC = 30;
% T_upper_NEDC = 60;
% T_TH_NEDC = T_lower_NEDC:1:T_upper_NEDC;
% 
% u_LPS_min_lower_NEDC = -0.1;
% u_LPS_min_upper_NEDC = -0.7;
% U_LPS_MIN_NEDC = u_LPS_min_lower_NEDC:-0.05:u_LPS_min_upper_NEDC;
% 
% soc_min_NEDC = 0.15;
% soc_max_NEDC = 0.20;
% SOC_NEDC = soc_min_NEDC:0.05:soc_max_NEDC;
% 
% [X_NEDC,Y_NEDC,Z_NEDC, SS_NEDC] = ndgrid(T_MGB_TH_NEDC, T_TH_NEDC, U_LPS_MIN_NEDC, SOC_NEDC);

tic;
%%
global T_MGB_th
global T
global u_LPS_min
global SOC_th

%Battery_Charge_FTP = zeros(size(X_FTP,1), size(Y_FTP,2), size(Z_FTP,3),size(SS_FTP,4));
%Consumption_Curve_FTP= zeros(size(X_FTP,1), size(Y_FTP,2), size(Z_FTP,3),size(SS_FTP,4));

Battery_Charge_NEDC = zeros(size(X_NEDC,1), size(Y_NEDC,2), size(Z_NEDC,3),size(SS_NEDC,4));
Consumption_Curve_NEDC= zeros(size(X_NEDC,1), size(Y_NEDC,2), size(Z_NEDC,3),size(SS_NEDC,4));
%% Run Simulation : FTP-75
% for x = 1:1:size(X_FTP,1)
%     for y = 1:1:size(Y_FTP,2)
%        for z = 1:1:size(Z_FTP,3)
%            for soc = 1:1:size(SS_FTP,4)
%                 T_MGB_th = X_FTP(x,y,z,soc);
%                 T = Y_FTP(x,y,z,soc);
%                 u_LPS_min = Z_FTP(x,y,z,soc);
%                 SOC_th = SS_FTP(x,y,z,soc);
%                 outputs = sim(filepath, 'StartTime','0','StopTime','1887', 'FixedStep', '1');
%                 if length(outputs.q_BT)>=1887
%                     Battery_Charge_FTP(x,y,z,soc) = outputs.q_BT(end);
%                     Consumption_Curve_FTP(x,y,z,soc) = outputs.V_CE_equiv(end);
%                 else
%                     Battery_Charge_FTP(x,y,z,soc) = Inf;
%                     Consumption_Curve_FTP(x,y,z,soc) = Inf;
%                 end
%            end
%         end
%     end
% end
% toc;
% save FTP_all_results.mat Battery_Charge_FTP Consumption_Curve_FTP X_FTP Y_FTP Z_FTP SS_FTP;
% % Fetch location of the value
% [val,loc] = min(Consumption_Curve_FTP(Consumption_Curve_FTP > 0));
% [xx,yy,zz,ss] = ind2sub(size(Consumption_Curve_FTP),loc);
% 
% save FTP_min_results.mat val X_FTP(xx,yy,zz,ss) Y_FTP(xx,yy,zz,ss) Z_FTP(xx,yy,zz,ss) SS_FTP(xx,yy,zz,ss);
% % eval(['FTP.SOC_' num2str(ss*100) '.V_CE_equiv =' num2str(val)]);
% % eval(['FTP.SOC_' num2str(ss*100) '.T_MGB_th =' num2str(X_FTP(xx,yy,zz,ss))]);
% % eval(['FTP.SOC_' num2str(ss*100) '.T =' num2str(Y_FTP(xx,yy,zz,ss))]);
% % eval(['FTP.SOC_' num2str(ss*100) '.u_LPS_min =' num2str(Z_FTP(xx,yy,zz,ss))]);
% % eval(['FTP.SOC_' num2str(ss*100) '.SOC_th =' num2str(SS_FTP(xx,yy,zz,ss))]);
% % save('FTP_results.mat', 'FTP')
%     
% Print values of parameters
% fprintf('==========================================================\n');
% fprintf('Minimum fuel consumption for FTP-75 = %s liter\n',num2str(val));
% fprintf('----------------------------------------------------------\n');
% fprintf('Parameters value at optimum point :\n');
% fprintf('----------------------------------------------------------\n');
% fprintf('T_MGB_th = %s Nm\n',num2str(X_FTP(xx,yy,zz,ss)));
% fprintf('T = %s Nm\n',num2str(Y_FTP(xx,yy,zz,ss)));
% fprintf('u_LPS_min = %s\n', num2str(Z_FTP(xx,yy,zz,ss)));
% fprintf('SOC = %s\n', num2str(SS_FTP(xx,yy,zz,ss)));
% fprintf('----------------------------------------------------------\n'); 
% 
%% Run Simulation : NEDC
% set NEDC cycle
set_param(strcat(filepath(1:end-4),'/Driving Cycle'),'cyclenr', 7) % DO NOT CHANGE
i =0;
for x = 1:1:size(X_NEDC,1)
   for y = 1:1:size(Y_NEDC,2)
       for z = 1:1:size(Z_NEDC,3)
           for soc= 1:1:size(SS_NEDC, 4)
               i = i+1;
                T_MGB_th = X_NEDC(x,y,z,soc);
                T = Y_NEDC(x,y,z,soc);
                u_LPS_min = Z_NEDC(x,y,z,soc);
                SOC_th = SS_NEDC(x,y,z,soc);
                outputs = sim(filepath, 'StartTime','0','StopTime','1220', 'FixedStep', '1');
                if length(outputs.q_BT)>=1220
                    Battery_Charge_NEDC(x,y,z,soc) = outputs.q_BT(end);
                    Consumption_Curve_NEDC(x,y,z,soc) = outputs.V_CE_equiv(end);
                else
                    Battery_Charge_NEDC(x,y,z,soc) = Inf;
                    Consumption_Curve_NEDC(x,y,z,soc) = Inf;
                end
           end
       end
   end
end

save NEDC_all_results.mat Battery_Charge_NEDC Consumption_Curve_NEDC X_NEDC Y_NEDC Z_NEDC SS_NEDC;

toc;
% Fetch location of the value
[val,loc] = min(Consumption_Curve_NEDC(Consumption_Curve_NEDC > 0));
[xx,yy,zz,ss] = ind2sub(size(Consumption_Curve_NEDC),loc);

save NEDC_min_results.mat val X_NEDC(xx,yy,zz,ss) Y_NEDC(xx,yy,zz,ss) Z_NEDC(xx,yy,zz,ss) SS_NEDC(xx,yy,zz,ss);

% eval(['NEDC.SOC_' num2str(ss*100) '.V_CE_equiv =' num2str(val)]);
% eval(['NEDC.SOC_' num2str(ss*100) '.T_MGB_th =' num2str(X_NEDC(xx,yy,zz,ss))]);
% eval(['NEDC.SOC_' num2str(ss*100) '.T =' num2str(Y_NEDC(xx,yy,zz,ss))]);
% eval(['NEDC.SOC_' num2str(ss*100) '.u_LPS_min =' num2str(Z_NEDC(xx,yy,zz,ss))]);
% eval(['NEDC.SOC_' num2str(ss*100) '.SOC_th =' num2str(SS_NEDC(xx,yy,zz,ss))]);
% save('NEDC_results.mat', 'NEDC')

%Print values of parameters
fprintf('==========================================================\n');
fprintf('Minimum fuel consumption for NEDC = %s liter\n',num2str(val));
fprintf('----------------------------------------------------------\n'); 
fprintf('Parameters value at optimum point :\n');
fprintf('----------------------------------------------------------\n');
fprintf('T_MGB_th = %s Nm\n',num2str(X_NEDC(xx,yy,zz,ss)));
fprintf('T = %s Nm\n',num2str(Y_NEDC(xx,yy,zz,ss))); 
fprintf('u_LPS_min = %s\n', num2str(Z_NEDC(xx,yy,zz,ss)));
fprintf('SOC = %s\n', num2str(SS_NEDC(xx,yy,zz,ss)));
fprintf('----------------------------------------------------------\n');
 
% %% Get parameter values at optimal point

% FTP-75
% 
% 
% % Fetch location of the value
% [val,loc] = min(Consumption_Curve_FTP(Consumption_Curve_FTP > 0));
% [xx,yy,zz] = ind2sub(size(Consumption_Curve_FTP),loc);
% 
% clc;
% 
% diary results.txt
% diary on;
% % Print values of parameters
% fprintf('==========================================================\n');
% fprintf('Minimum fuel consumption for FTP-75 = %s liter\n',num2str(val));
% fprintf('----------------------------------------------------------\n');
% fprintf('Parameters value at optimum point :\n');
% fprintf('----------------------------------------------------------\n');
% fprintf('T_MGB_th = %s Nm\n',num2str(X_FTP(xx,yy,zz)));
% fprintf('T = %s Nm\n',num2str(Y_FTP(xx,yy,zz)));
% fprintf('u_LPS_min = %s\n', num2str(Z_FTP(xx,yy,zz)));
% fprintf('----------------------------------------------------------\n');
% 
% diary off;
% 
% % NEDC
% 
% % Fetch location of the value
% [val, loc] = min(Consumption_Curve_NEDC(Consumption_Curve_NEDC > 0));
% [xx,yy,zz] = ind2sub(size(Consumption_Curve_NEDC),loc);   
% 
% diary on;
% % Print values of parameters
% fprintf('==========================================================\n');
% fprintf('Minimum fuel consumption for NEDC = %s liter\n',num2str(val));
% fprintf('----------------------------------------------------------\n');
% fprintf('Parameters value at optimum point :\n');
% fprintf('----------------------------------------------------------\n');
% fprintf('T_MGB_th = %s Nm\n',num2str(X_NEDC(xx,yy,zz)));
% fprintf('T = %s Nm\n',num2str(Y_NEDC(xx,yy,zz)));
% fprintf('u_LPS_min = %s\n', num2str(Z_NEDC(xx,yy,zz)));
% fprintf('----------------------------------------------------------\n');
% 
% 
% diary off;
